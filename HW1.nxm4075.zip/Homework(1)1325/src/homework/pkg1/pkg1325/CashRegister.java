/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class CashRegister {
    private float current_money;
    
    public CashRegister()
    {
        
    }
    
    public String display_current_money() {
        String result="";
        result=result+String.format("price is: $%3.2f.%n",current_money);
        return result;
    }
     public void setCurrent_money(float fInput)
    {
        current_money=fInput;
    }
    
}
