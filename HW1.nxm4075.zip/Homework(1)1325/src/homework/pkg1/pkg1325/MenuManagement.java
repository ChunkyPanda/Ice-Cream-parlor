/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

import java.util.Scanner;

/**
 *
 * @author Neil
 */
public class MenuManagement {
    
    private Shop shop;   
   
    private String answer;
    private final Scanner keyboard; 
    
    //The Constructor
    public MenuManagement()
    {
        answer="";
        keyboard=new Scanner(System.in);
    }  
    
    
    public void setShop(Shop shop) {
        this.shop=shop;
    }

    public void go() {
        boolean mainLoop;
        mainLoop=true;
        
        while (mainLoop)
        {
            System.out.println("Main Menu");
            System.out.println("======================");
            System.out.println("1. Create Menu");
            System.out.println("2. Update Menu");
            System.out.println("P. Display All");
            System.out.println("Q. Quit");
            System.out.println("----------------------");
            System.out.print  ("::>");
            answer=keyboard.nextLine();
 
            switch(answer)
            {
                case "1":
                    menuCreate();
                    break;
                case "2":
                    menuUpdate();
                    break;
                case "p":
                case "P":
                    displayAll();
                    break;
                case "q":
                case "Q":
                    mainLoop=false;
                    break;
            }
        }
    }
    
     private void menuCreate() {
        boolean createLoop;
        createLoop=true;
        
        while (createLoop)
        {
            System.out.println("Create Menu");
            System.out.println("======================");
            System.out.println("1. Create IceCream");
            System.out.println("2. Create serving");
            System.out.println("3. Create Customer");
            System.out.println("4. Create Worker");
            System.out.println("5. Create Order");
            System.out.println("Q. Previous Menu");
            System.out.println("----------------------");
            System.out.print  ("::>");
            answer=keyboard.nextLine();
     
            
            switch(answer)
            {
                case "1":
                    shop.createIce_cream();
                    break;
                case "2":
                    shop.createServing();
                    break;
                case "3":
                    shop.createCustomer();
                    break;
                case "4":
                    shop.createWorker();
                    break;
                case "5":
                    shop.createOrder();
                    break;
                case "q":
                case "Q":
                    createLoop=false;
                    break;
            }
        }        
     }
    
     private void menuUpdate() {
        boolean updateLoop;
        updateLoop=true;
        
        String sInput;
        float fInput;
        int iInput;
        
        while (updateLoop)
        {
            System.out.println("Update Menu");
            System.out.println("======================");
            System.out.println("1. Update Ice Cream");
            System.out.println("2. Update Serving");
            System.out.println("3. Update Customer");
            System.out.println("4. Update Worker");
            System.out.println("5. Update Order");
            System.out.println("Q. Previous Menu");
            System.out.println("----------------------");
            System.out.print  ("::>");
            answer=keyboard.nextLine();
 
            switch(answer)
            {
                case "1"://Ice Cream
                    System.out.println("Please enter a Ice cream name as a text");
                    sInput=keyboard.nextLine();
                    shop.updateName(sInput);
                    System.out.println("Please enter a Ice cream Flavor as a text");
                    sInput=keyboard.nextLine();
                    shop.updateFlavor(sInput);
                    System.out.println("Please enter a Ice cream description as a text");
                    sInput=keyboard.nextLine();
                    shop.updateDescription(sInput);
                    System.out.println("Please enter the price of Ice Cream as a float");
                    fInput=keyboard.nextFloat();
                    shop.updatePrice(fInput);
                    break;
                case "2"://serving
                    System.out.println("Please enter a number of flavors as an integer");
                    sInput=keyboard.nextLine();
                    shop.updateNumber_of_flavors(sInput);
                    System.out.println("Please enter Over all price as a float");
                    fInput=keyboard.nextFloat();
                    shop.updateOver_all_price(fInput);
                    
                    break;
                case "3"://customer  
                    System.out.println("Please enter customer name as text.");
                    sInput= keyboard.nextLine();
                    shop.updateCustomer_name(sInput);
                    break;
                    
                case "4": //worker
                    break;
                case "5"://Order
                    System.out.println("Please enter status of order as text.");
                    sInput= keyboard.nextLine();
                    shop.updateStatus(sInput);
                    System.out.println("Please enter order number as an integer");
                    iInput=keyboard.nextInt();
                    shop.updateOrder_number(iInput);
                    
                case "q":
                case "Q":
                    updateLoop=false;
                    break;
            }
        }        
    }

    private void displayAll() {
        Order localD=shop.getOrder();
        Customer localC=shop.getCustomer();
        IceCream localT=shop.getIce_cream();
        Serving localW=shop.getServing();
        Worker localE=shop.getWorker();
        
        System.out.println("Status");
        System.out.println("-------------");
        if (localD!=null)
        {
            System.out.println(localD.display_Order_number());
        }
        else
        {
            System.out.println("Order is not instantiated!");
        }
        
        
        if (localC!=null)
        {
            System.out.println(localC.display_customer_name());
        }
        else
        {
            System.out.println("Customer is not instantiated!");
        }
        
        
        if (localW!=null)
        {
            System.out.println(localW.display_number_of_flavors());
        }
        else
        {
            System.out.println("serving is not instantiated!");
        }
        if (localT!=null)
        {
            System.out.println(localT.display_description());
        }
        else
        {
            System.out.println("serving is not instantiated!");
        }
        if (localE!=null)
        {
            System.out.println(localE.display_worker_name());
        }
        else
        {
            System.out.println("Worker is not instantiated!");
        }
        
        
        
        
    }
    
}

