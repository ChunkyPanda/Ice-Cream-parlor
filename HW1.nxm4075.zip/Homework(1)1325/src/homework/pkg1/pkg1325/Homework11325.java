/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class Homework11325
{public MenuManagement menuManage;
public Shop shoppe;
 
    public Homework11325()
{
         menuManage=new MenuManagement();//Allocate Memory for the Menu Manager
      shoppe = new Shop();//Allocate Memory for the Sub Controller
        menuManage.setShop(shoppe);//Set an attribute in the Menu Manager to point to the Sub Controller
    }
    
    public void go()
    {
        menuManage.go();//Start the Menu Manager
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Homework11325 btui=new Homework11325();//Allocate memory for the MAIN
        btui.go();//Start the Program
    }
    
}

