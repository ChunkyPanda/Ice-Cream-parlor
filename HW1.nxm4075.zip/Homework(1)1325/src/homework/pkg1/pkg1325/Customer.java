/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class Customer {
    
    private String customer_name;
    private String level_of_happiness;
    private float money_available;
    
    public Customer()
    {
        
    }
    public String display_customer_name() {
        String result="";
        result=result+String.format("Customer Name: ");
        result=result+String.format("\"");
        result=result+String.format(customer_name);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    public String display_level_of_happiness() {
        String result="";
        result=result+String.format("level_of_happiness: ");
        result=result+String.format("\"");
        result=result+String.format(level_of_happiness);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    public String display_money_available() {
        String result="";
        result=result+String.format("Money available is: $%3.2f.%n",money_available);
        return result;
    }
    public void setCustomer_name(String sInput) {
        customer_name=sInput;
    }
    public void setLevel_of_happiness(String sInput) {
        level_of_happiness=sInput;
    }
    public void setMoney_available(float fInput)
    {
        money_available=fInput;
    }
    
}
