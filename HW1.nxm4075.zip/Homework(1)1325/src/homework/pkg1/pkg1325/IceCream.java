/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class IceCream{
    public String flavor;
    public double price;
    public String name;
    public String description;
    
    public IceCream()
    {
        description="";
        name="";
        flavor="";
        price=0.0;
    }
    public String display_description() {
        String result="";
        result=result+String.format("description: ");
        result=result+String.format("\"");
        result=result+String.format(description);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    
    public String display_flavor() {
        String result="";
        result=result+String.format("Flavor: ");
        result=result+String.format("\"");
        result=result+String.format(flavor);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    public String display_name() {
        String result="";
        result=result+String.format("Name: ");
        result=result+String.format("\"");
        result=result+String.format(name);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    public String display_price() {
        String result="";
        result=result+String.format("price is: $%3.2f.%n",price);
        return result;
    }
    public void setDescription(String sInput) {
        description=sInput;
    }
    public void setFlavor(String sInput) {
        flavor=sInput;
    }
    public void setName(String sInput) {
        name=sInput;
    }
    public void setPrice(double dInput)
    {
        price=dInput;
    }
    }

