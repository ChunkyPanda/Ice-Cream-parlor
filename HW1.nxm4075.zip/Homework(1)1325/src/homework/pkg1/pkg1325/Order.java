/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class Order {
 private String status;
 private int order_number;
 
 public Order()
 {
     
 }
 public String display_status() {
        String result="";
        result=result+String.format("Status: ");
        result=result+String.format("\"");
        result=result+String.format(status);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    public String display_Order_number() {
        String result="";
        result=result+String.format("price is: %d",order_number);
        return result;
    }
    
    public void setStatus(String sInput) {
        status=sInput;
    }
    public void setOrder_number(int iInput)
    {
        order_number=iInput;
    }}
    