/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class Shop{
    
    private IceCream ice_cream;
    private Customer customer;
    private CashRegister cash_register;
    private Order order;
    private Serving serving;
    private Worker worker;
    
    public void createIce_cream() {
        ice_cream=new IceCream();
        System.out.println("Ice cream was created");
    }
    public void createCustomer() {
        customer=new Customer();
        System.out.println("Customer was created");
    }
    public void createDoohickey() {
        cash_register=new CashRegister();
        System.out.println("Cash Register was created");
    }
    public void createOrder() {
        order=new Order();
        System.out.println("Order was created");
    }
    public void createServing() {
        serving=new Serving();
        System.out.println("Serving was created");
    }
    public void createWorker() {
        worker=new Worker();
        System.out.println("Worker was created");
    }
    public IceCream getIce_cream()
    {
        return ice_cream;
    }
    public Customer getCustomer() {
        return customer;
    }
    public CashRegister getCash_register() {
        return cash_register;
    }
    public Order getOrder() {
        return order;
    }
    public Serving getServing() {
        return serving;
    }
    public Worker getWorker() {
        return worker;
    }
    public void updateFlavor(String sInput) {
        ice_cream.setFlavor(sInput);
    }
    public void updateName(String sInput) {
        ice_cream.setName(sInput);
    }
    public void updateDescription(String sInput) {
        ice_cream.setDescription(sInput);
    }
    public void updatePrice(float fInput) {
        ice_cream.setPrice(fInput);
    }
    public void updateCurrent_money(float fInput) {
        cash_register.setCurrent_money(fInput);
    }
    public void updateCustomer_name(String fInput) {
        customer.setCustomer_name(fInput);
    }
    public void updateOrder_number(int dInput) {
        order.setOrder_number(dInput);
    }
    public void updateStatus(String fInput) {
        order.setStatus(fInput);
    }
    public void updateOver_all_price(float fInput) {
        serving.setOver_all_price(fInput);
    }

    public void updateNumber_of_flavors(String sInput) {
        serving.setNumber_of_flavors(sInput);
    }
}
