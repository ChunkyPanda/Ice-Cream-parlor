/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class Serving {
    private String number_of_flavors;
    private float over_all_price;
    
    public Serving()
    {
        
    }
    public String display_number_of_flavors() {
        String result="";
        result=result+String.format("number of flavors is: %s",number_of_flavors);
        return result;
    }
    public String display_Over_all_price() {
        String result="";
        result=result+String.format("price is: $%3.2f.%n",over_all_price);
        return result;
    }
    
    public void setOver_all_price(float fInput)
    {
        over_all_price=fInput;
    }
    public void setNumber_of_flavors(String sInput)
    {
        number_of_flavors=sInput;
    }
}
