/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework.pkg1.pkg1325;

/**
 *
 * @author Neil
 */
public class Worker {
    public String worker_name; 
    public Worker()
    {
        
    }
    public String display_worker_name() {
        String result="";
        result=result+String.format("Worker_name: ");
        result=result+String.format("\"");
        result=result+String.format(worker_name);
        result=result+String.format("\"");
        result=result+String.format("\n");
       return result;
    }
    public void setWorker_name(String sInput) {
        worker_name=sInput;
    }
}