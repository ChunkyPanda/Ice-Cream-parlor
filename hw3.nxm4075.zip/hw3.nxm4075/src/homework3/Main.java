package homework3;

/**
 *
 * @author Neil
 */

public class Main {

    private MenuManager menuManager;
    private Shop shopper; 


    //The Constructor for the MAIN class
    public Main() {
        menuManager = new MenuManager();
        shopper = new Shop();
        menuManager.setShopcontroller(shopper);
    }

    public void go() {
        menuManager.go();//Start the Menu Manager
    }

    
    public static void main(String[] args) {
        
        Main main = new Main();
        main.go();
    }
}
